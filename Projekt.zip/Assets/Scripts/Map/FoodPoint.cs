﻿using UnityEngine;

public class FoodPoint: MonoBehaviour
{
    public int Point;
}
