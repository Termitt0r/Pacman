﻿public enum Direction
{
    Left = 0,
    Right = 1,
    Up = 2,
    Down = 3,

    None = 4,
}
